<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login - Pastimes</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="auth-container">
    <div class="auth-left">
        <h1>Welcome Back</h1>
        <p>Login to continue buying and selling quality pre-owned fashion.</p>
    </div>
    <div class="auth-right">
        <div class="auth-form">
            <h2>Login</h2>
            <p class="form-note">Prototype login page: user details are checked against tblUser in the final system.</p>
            <form method="POST" action="profile.php">
                <input type="text" name="username" placeholder="Username" required>
                <input type="email" name="email" placeholder="Email Address" required>
                <input type="password" name="password" placeholder="Password" minlength="8" required>
                <button type="submit" class="btn full">Login</button>
            </form>
            <p>Don't have an account? <a href="register.php">Register</a></p>
            <p><a href="adminLogin.php">Admin Login</a></p>
        </div>
    </div>
</div>
</body>
</html>

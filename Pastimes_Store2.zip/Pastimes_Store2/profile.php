<!DOCTYPE html>
<html lang="en">
<head>
    <title>Profile - Pastimes</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include 'partial_header.php'; ?>
<main class="page-container">
    <div class="profile-card panel">
        <div class="avatar">P</div>
        <h1>PFano Dzivhani</h1>
        <p>Buyer/Seller Account</p>
        <div class="profile-grid">
            <div><strong>Email</strong><span>user@example.com</span></div>
            <div><strong>Status</strong><span>Approved</span></div>
            <div><strong>Orders</strong><span>2 Purchases</span></div>
            <div><strong>Listings</strong><span>1 Item for Sale</span></div>
        </div>
        <a href="products.php" class="btn">Continue Shopping</a>
    </div>
</main>
<footer class="footer">Pastimes © 2026 | Buy. Sell. Wear Again.</footer>
</body>
</html>

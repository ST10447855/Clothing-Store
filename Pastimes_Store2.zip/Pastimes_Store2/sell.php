<?php
/*session_start();
include 'config.php';

if(isset($_POST['submit'])){

    $name = $_POST['name'];
    $brand = $_POST['brand'];
    $price = $_POST['price'];
    $category = $_POST['category'];
    $condition = $_POST['condition'];
    $size = $_POST['size'];
    $description = $_POST['description'];

    // IMAGE
    $image = $_FILES['image']['name'];
    $temp = $_FILES['image']['tmp_name'];
    move_uploaded_file($temp, "images/".$image);

    // INSERT
    $sql = "INSERT INTO products (ProductName, Price, Description, Image)
            VALUES ('$name','$price','$description','$image')";

    $conn->query($sql);

    echo "<script>alert('Item listed successfully!');</script>";
}*/
?>

<!DOCTYPE html>
<html>
<head>
    <title>Sell Your Clothes</title>
    <link rel="stylesheet" href="style.css">
<script>
function toggleMenu() {
    var menu = document.getElementById("nav-links");
    menu.classList.toggle("active");
}
</script>
</head>

<body>

<header class="navbar">

    <div class="logo">
        <img src="images/logo.jpeg" alt="logo">
        <span>Pastimes</span>
    </div>

    <!-- BURGER ICON -->
    <div class="menu-toggle" onclick="toggleMenu()">☰</div>

    <nav id="nav-links">
        <a href="index.php">Home</a>
        <a href="products.php">Shop</a>
        <a href="sell.php">Sell Your Clothes</a>
        <a href="#">Messages</a>
         <a href="product_details.php">View Details</a>
         <a href="cart.php">Cart</a>
        <a href="checkout.php">CheckOut</a>
        <a href="login.php">Login</a>
        <a href="register.php" class="btn-signup">Sign Up</a>
    </nav>
</header>

<div class="sell-container">

    <h2>List Your Item for Sale</h2>

    <form method="POST" enctype="multipart/form-data">

        <!-- BASIC INFO -->
        <h3>Basic Information</h3>

        <input type="text" name="name" placeholder="Item Name" required>
        <input type="text" name="brand" placeholder="Brand" required>
        <input type="number" name="price" placeholder="Price (R)" required>

        <!-- CATEGORY -->
        <h3>Category & Details</h3>

        <select name="category" required>
            <option value="">Select Category</option>
            <option>Jacket</option>
            <option>Shoes</option>
            <option>Dress</option>
            <option>T-Shirt</option>
        </select>

        <select name="condition" required>
            <option value="">Condition</option>
            <option>Like New</option>
            <option>Good</option>
            <option>Used</option>
        </select>

        <input type="text" name="size" placeholder="Size (S, M, L, XL)">

        <!-- DESCRIPTION -->
        <h3>Description</h3>

        <textarea name="description" rows="4" placeholder="Describe your item..." style="width:100%; padding:10px;"></textarea>

        <!-- IMAGE -->
        <h3>Upload Image</h3>

        <input type="file" name="image" id="imageInput" required>

        <img id="preview" style="width:150px; margin-top:10px; display:none;">

        <button type="submit" name="submit" class="btn">List Item</button>

    </form>

</div>

<script>
// IMAGE PREVIEW
document.getElementById("imageInput").onchange = function(e){
    let reader = new FileReader();
    reader.onload = function(){
        let img = document.getElementById("preview");
        img.src = reader.result;
        img.style.display = "block";
    }
    reader.readAsDataURL(e.target.files[0]);
}
</script>

</body>
</html>
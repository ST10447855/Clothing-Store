<?php
// DBConn.php - database connection for Pastimes ClothingStore
$serverName = "localhost";
$userName = "root";
$password = "";
$databaseName = "ClothingStore";

$conn = new mysqli($serverName, $userName, $password, $databaseName);

if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}
?>

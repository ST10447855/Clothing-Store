<?php
// loadClothingStore.php - creates Pastimes database tables
$serverName = "localhost";
$userName = "root";
$password = "";

$conn = new mysqli($serverName, $userName, $password);
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error); }

$conn->query("CREATE DATABASE IF NOT EXISTS ClothingStore");
$conn->select_db("ClothingStore");

$sql = file_get_contents("myClothingStore.sql");
if ($conn->multi_query($sql)) {
    echo "ClothingStore database loaded successfully.";
} else {
    echo "Error loading database: " . $conn->error;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin Login - Pastimes</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="auth-container">
    <div class="auth-left admin-bg">
        <h1>Admin Portal</h1>
        <p>Verify users and manage products for Pastimes.</p>
    </div>
    <div class="auth-right">
        <div class="auth-form">
            <h2>Admin Login</h2>
            <form method="POST" action="adminDashboard.php">
                <input type="email" name="adminEmail" placeholder="Admin Email" required>
                <input type="password" name="password" placeholder="Password" minlength="8" required>
                <button type="submit" class="btn full">Login as Admin</button>
            </form>
            <p><a href="index.php">Back to Home</a></p>
        </div>
    </div>
</div>
</body>
</html>

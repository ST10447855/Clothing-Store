<!DOCTYPE html>
<html lang="en">
<head>
    <title>Register - Pastimes</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="auth-container">
    <div class="auth-left">
        <h1>Join Pastimes</h1>
        <p>Create an account to buy and sell clothing easily.</p>
    </div>
    <div class="auth-right">
        <div class="auth-form">
            <h2>Create Account</h2>
            <p class="form-note">New accounts are pending until approved by an administrator.</p>
            <form method="POST" action="login.php">
                <input type="text" name="fullName" placeholder="Full Name" required>
                <input type="email" name="email" placeholder="Email Address" required>
                <input type="text" name="username" placeholder="Username" required>
                <input type="password" name="password" placeholder="8-character Password" minlength="8" required>
                <input type="password" name="confirm" placeholder="Confirm Password" minlength="8" required>
                <select name="role" required>
                    <option value="">Select Role</option>
                    <option value="Buyer">Buyer</option>
                    <option value="Seller">Seller</option>
                </select>
                <button type="submit" class="btn full">Register</button>
            </form>
            <p>Already have an account? <a href="login.php">Login</a></p>
        </div>
    </div>
</div>
</body>
</html>

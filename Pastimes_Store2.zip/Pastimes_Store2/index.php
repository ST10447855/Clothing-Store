<?php session_start(); include 'products_data.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Pastimes | Pre-Owned Fashion</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include 'partial_header.php'; ?>
<section class="hero">
    <div class="hero-content">
        <p class="eyebrow">Second-hand fashion store</p>
        <h1>Wear It Again. Own It Better.</h1>
        <p>Buy and sell quality pre-owned fashion with a clean, trusted and stylish shopping experience.</p>
        <div class="hero-actions">
            <a href="products.php" class="btn">Shop Now</a>
            <a href="sell.php" class="btn btn-outline">Sell Your Clothes</a>
        </div>
    </div>
</section>

<section class="features-strip">
    <div><strong>Affordable</strong><span>Quality fashion at better prices</span></div>
    <div><strong>Sustainable</strong><span>Give clothing another life</span></div>
    <div><strong>Trusted</strong><span>Admin-verified seller process</span></div>
</section>

<section class="products">
    <h2>Featured Items</h2>
    <p class="section-intro">A quick look at stylish items available on Pastimes.</p>
    <div class="product-grid">
        <?php foreach (array_slice($products,0,4,true) as $p): ?>
        <div class="card">
            <img src="images/<?php echo htmlspecialchars($p['image']); ?>" alt="<?php echo htmlspecialchars($p['name']); ?>">
            <div class="card-body">
                <span class="tag"><?php echo htmlspecialchars($p['brand']); ?></span>
                <h3><?php echo htmlspecialchars($p['name']); ?></h3>
                <p class="price">R<?php echo number_format($p['price'],0); ?></p>
                <div class="card-actions">
                    <a href="product_details.php?id=<?php echo $p['id']; ?>" class="btn-small">View</a>
                    <a href="add_to_cart.php?id=<?php echo $p['id']; ?>" class="btn-small primary">Add to Cart</a>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</section>
<footer class="footer">Pastimes © 2026 | Buy. Sell. Wear Again.</footer>
</body>
</html>

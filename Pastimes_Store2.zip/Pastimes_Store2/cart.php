<?php
session_start();
include 'products_data.php';
$cart = $_SESSION['cart'] ?? [];
$total = 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Shopping Cart - Pastimes</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include 'partial_header.php'; ?>
<main class="page-container cart-page">
    <div class="page-heading">
        <p class="eyebrow">Review your order</p>
        <h1>Your Cart</h1>
        <p>Edit your items before continuing to checkout.</p>
    </div>
    <div class="cart-layout">
        <section class="panel">
            <?php if (empty($cart)): ?>
                <div class="empty-state">
                    <h2>Your cart is empty</h2>
                    <p>Start shopping to add your favourite pre-owned pieces.</p>
                    <a href="products.php" class="btn">Continue Shopping</a>
                </div>
            <?php else: ?>
                <?php foreach ($cart as $id => $qty): $p = $products[$id]; $line = $p['price'] * $qty; $total += $line; ?>
                <div class="cart-item">
                    <img src="images/<?php echo htmlspecialchars($p['image']); ?>" alt="<?php echo htmlspecialchars($p['name']); ?>">
                    <div class="cart-info">
                        <h3><?php echo htmlspecialchars($p['name']); ?></h3>
                        <p><?php echo htmlspecialchars($p['brand']); ?> • <?php echo htmlspecialchars($p['condition']); ?></p>
                        <p class="price">R<?php echo number_format($p['price'],0); ?></p>
                    </div>
                    <div class="qty-controls">
                        <a href="update_cart.php?id=<?php echo $id; ?>&action=decrease">−</a>
                        <span><?php echo $qty; ?></span>
                        <a href="update_cart.php?id=<?php echo $id; ?>&action=increase">+</a>
                    </div>
                    <strong>R<?php echo number_format($line,0); ?></strong>
                    <a href="update_cart.php?id=<?php echo $id; ?>&action=remove" class="remove-link">Remove</a>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </section>
        <aside class="panel summary-panel">
            <h2>Order Summary</h2>
            <div class="summary-row"><span>Subtotal</span><strong>R<?php echo number_format($total,0); ?></strong></div>
            <div class="summary-row"><span>Delivery</span><strong>Free</strong></div>
            <div class="summary-row total"><span>Total</span><strong>R<?php echo number_format($total,0); ?></strong></div>
            <a href="checkout.php" class="btn full <?php echo empty($cart) ? 'disabled' : ''; ?>">Proceed to Checkout</a>
            <a href="products.php" class="continue-link">Continue Shopping</a>
        </aside>
    </div>
</main>
<footer class="footer">Pastimes © 2026 | Buy. Sell. Wear Again.</footer>
</body>
</html>

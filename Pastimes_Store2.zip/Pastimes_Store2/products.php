<?php session_start(); include 'products_data.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Shop - Pastimes</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include 'partial_header.php'; ?>
<main class="page-container">
    <div class="page-heading">
        <p class="eyebrow">Shop verified pieces</p>
        <h1>Shop Pre-Owned Fashion</h1>
        <p>Browse quality second-hand branded clothing and accessories.</p>
    </div>
    <div class="product-grid">
        <?php foreach ($products as $p): ?>
        <div class="card">
            <img src="images/<?php echo htmlspecialchars($p['image']); ?>" alt="<?php echo htmlspecialchars($p['name']); ?>">
            <div class="card-body">
                <span class="tag"><?php echo htmlspecialchars($p['condition']); ?></span>
                <h3><?php echo htmlspecialchars($p['name']); ?></h3>
                <p><?php echo htmlspecialchars($p['brand']); ?> • <?php echo htmlspecialchars($p['size']); ?></p>
                <p class="price">R<?php echo number_format($p['price'],0); ?></p>
                <div class="card-actions">
                    <a href="product_details.php?id=<?php echo $p['id']; ?>" class="btn-small">View Details</a>
                    <a href="add_to_cart.php?id=<?php echo $p['id']; ?>" class="btn-small primary">Add to Cart</a>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</main>
<footer class="footer">Pastimes © 2026 | Buy. Sell. Wear Again.</footer>
</body>
</html>

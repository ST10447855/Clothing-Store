PASTIMES STORE - PART 2 PROTOTYPE

Students:
PFano Dzivhani - ST10447855
Precious Makobe - ST10440411

How to run:
1. Copy Pastimes_Store2 folder into XAMPP htdocs.
2. Start Apache and MySQL in XAMPP.
3. Open phpMyAdmin and import myClothingStore.sql OR run loadClothingStore.php.
4. Open http://localhost/Pastimes_Store2/index.php in a browser.

Important files:
- DBConn.php: database connection
- createTable.php: recreates tblUser and loads userData.txt
- loadClothingStore.php: creates all database tables
- userData.txt: five fictitious user records
- myClothingStore.sql: DDL and sample inserts

Prototype pages:
- index.php
- products.php
- product_details.php
- cart.php
- checkout.php
- order-success.php
- login.php
- register.php
- sell.php
- messages.php
- profile.php
- adminLogin.php
- adminDashboard.php

<?php
session_start();
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$action = $_GET['action'] ?? '';
if (isset($_SESSION['cart'][$id])) {
    if ($action === 'increase') { $_SESSION['cart'][$id]++; }
    if ($action === 'decrease') { $_SESSION['cart'][$id]--; }
    if ($action === 'remove' || $_SESSION['cart'][$id] <= 0) { unset($_SESSION['cart'][$id]); }
}
header('Location: cart.php');
exit;
?>

<?php
$products = [
    1 => ['id'=>1,'name'=>'Nike Air Max','brand'=>'Nike','price'=>200,'image'=>'shoe.jpg','description'=>'Pre-owned Nike Air Max sneakers in good condition. Comfortable for everyday wear.','condition'=>'Good','size'=>'UK 6'],
    2 => ['id'=>2,'name'=>'Denim Jacket','brand'=>'Levi\'s','price'=>60,'image'=>'jecket.jpg','description'=>'Classic denim jacket with a relaxed fit. Perfect for casual outfits.','condition'=>'Used','size'=>'M'],
    3 => ['id'=>3,'name'=>'Tropical Heels','brand'=>'Aldo','price'=>170,'image'=>'heels.jpeg','description'=>'Stylish heels for special events and weekend fashion looks.','condition'=>'Like New','size'=>'UK 5'],
    4 => ['id'=>4,'name'=>'Coach Bag','brand'=>'Coach','price'=>250,'image'=>'Coach.jpeg','description'=>'Elegant branded handbag with enough space for daily essentials.','condition'=>'Good','size'=>'One Size'],
    5 => ['id'=>5,'name'=>'Tropical Top','brand'=>'Zara','price'=>100,'image'=>'Top.jpeg','description'=>'Light fashion top with a bright, stylish pattern.','condition'=>'Good','size'=>'S'],
    6 => ['id'=>6,'name'=>'Couture Handbag','brand'=>'Couture Collection','price'=>300,'image'=>'Coutoure Collection.jpeg','description'=>'Chic handbag for a high-fashion look.','condition'=>'Like New','size'=>'One Size'],
    7 => ['id'=>7,'name'=>'Designer Purse','brand'=>'Couture Collective','price'=>600,'image'=>'CoutoureCollective.jpeg','description'=>'Premium purse for formal and everyday styling.','condition'=>'Good','size'=>'One Size'],
    8 => ['id'=>8,'name'=>'Gucci Inspired Bag','brand'=>'Gucci','price'=>400,'image'=>'bag.jpg','description'=>'Statement bag with a luxury feel for modern outfits.','condition'=>'Good','size'=>'One Size'],
];
?>

<?php
// createTable.php - recreates tblUser and loads five sample users
include 'DBConn.php';

$conn->query("DROP TABLE IF EXISTS tblCart");
$conn->query("DROP TABLE IF EXISTS tblOrder");
$conn->query("DROP TABLE IF EXISTS tblUser");

$createUserTable = "CREATE TABLE tblUser (
    userID INT AUTO_INCREMENT PRIMARY KEY,
    fullName VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(50) DEFAULT 'Buyer',
    status VARCHAR(50) DEFAULT 'Pending'
)";

if ($conn->query($createUserTable) === TRUE) {
    echo "tblUser created successfully.<br>";
} else {
    die("Error creating tblUser: " . $conn->error);
}

$file = fopen("userData.txt", "r");
while (($line = fgetcsv($file)) !== FALSE) {
    $stmt = $conn->prepare("INSERT INTO tblUser (fullName, email, username, password, role, status) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $line[0], $line[1], $line[2], $line[3], $line[4], $line[5]);
    $stmt->execute();
}
fclose($file);

echo "Data loaded from userData.txt successfully.";
?>

<!DOCTYPE html>
<html>
<head>
    <title>Messages - Pastimes</title>
    <link rel="stylesheet" href="style.css">
<script>
function toggleMenu() {
    var menu = document.getElementById("nav-links");
    menu.classList.toggle("active");
}
</script>
</head>

<body>

<header class="navbar">

    <div class="logo">
        <img src="images/logo.jpeg" alt="logo">
        <span>Pastimes</span>
    </div>

    <!-- BURGER ICON -->
    <div class="menu-toggle" onclick="toggleMenu()">☰</div>

    <!-- NAV LINKS -->
    <nav id="nav-links">
        <a href="index.php">Home</a>
        <a href="products.php">Shop</a>
        <a href="sell.php">Sell</a>
        <a href="messages.php">Messages</a>
        <a href="cart.php">Cart</a>
        <a href="checkout.php">Checkout</a>
        <a href="login.php">Login</a>
        <a href="register.php" class="btn-signup">Sign Up</a>
    </nav>

</header>
</header>

<div class="page-container">

    <h2>Messages</h2>

    <div class="chat-box">
        <p><strong>Seller:</strong> Hi, is the jacket still available?</p>
        <p><strong>You:</strong> Yes, it is available.</p>
    </div>

    <form class="simple-form">
        <input type="text" placeholder="Type your message...">
        <button class="btn">Send</button>
    </form>

</div>

</body>
</html>
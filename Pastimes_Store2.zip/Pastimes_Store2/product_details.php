<?php
session_start();
include 'products_data.php';
$id = isset($_GET['id']) ? (int)$_GET['id'] : 1;
$product = $products[$id] ?? $products[1];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title><?php echo htmlspecialchars($product['name']); ?> - Pastimes</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include 'partial_header.php'; ?>
<main class="page-container">
    <div class="details-container">
        <img src="images/<?php echo htmlspecialchars($product['image']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" class="details-image">
        <div class="details-text panel">
            <p class="eyebrow"><?php echo htmlspecialchars($product['brand']); ?></p>
            <h1><?php echo htmlspecialchars($product['name']); ?></h1>
            <p class="price large">R<?php echo number_format($product['price'],0); ?></p>
            <p><strong>Condition:</strong> <?php echo htmlspecialchars($product['condition']); ?></p>
            <p><strong>Size:</strong> <?php echo htmlspecialchars($product['size']); ?></p>
            <p><?php echo htmlspecialchars($product['description']); ?></p>
            <a href="add_to_cart.php?id=<?php echo $product['id']; ?>" class="btn">Add to Cart</a>
            <a href="messages.php" class="btn btn-outline dark">Message Seller</a>
        </div>
    </div>
</main>
<footer class="footer">Pastimes © 2026 | Buy. Sell. Wear Again.</footer>
</body>
</html>

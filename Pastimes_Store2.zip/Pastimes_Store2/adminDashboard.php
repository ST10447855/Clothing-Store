<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin Dashboard - Pastimes</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include 'partial_header.php'; ?>
<main class="page-container">
    <div class="page-heading">
        <p class="eyebrow">Administrator</p>
        <h1>Admin Dashboard</h1>
        <p>Verify registrations and manage users/products.</p>
    </div>
    <section class="panel">
        <h2>Pending User Registrations</h2>
        <table class="admin-table">
            <tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Action</th></tr>
            <tr><td>Mary Smith</td><td>mary@example.com</td><td>Buyer</td><td>Pending</td><td><button>Approve</button> <button>Delete</button></td></tr>
            <tr><td>Aisha Khan</td><td>aisha@example.com</td><td>Seller</td><td>Pending</td><td><button>Approve</button> <button>Delete</button></td></tr>
        </table>
    </section>
    <section class="panel">
        <h2>Product Management</h2>
        <p>Admin can add, update and delete clothing items from the database.</p>
        <div class="admin-actions"><button>Add Product</button><button>Update Product</button><button>Delete Product</button></div>
    </section>
</main>
<footer class="footer">Pastimes © 2026 | Buy. Sell. Wear Again.</footer>
</body>
</html>

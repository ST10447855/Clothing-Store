<?php
session_start();
include 'products_data.php';
$cart = $_SESSION['cart'] ?? [];
$total = 0;
foreach ($cart as $id => $qty) { if (isset($products[$id])) { $total += $products[$id]['price'] * $qty; } }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Checkout - Pastimes</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include 'partial_header.php'; ?>
<main class="page-container">
    <div class="page-heading">
        <p class="eyebrow">Secure checkout</p>
        <h1>Delivery Details</h1>
        <p>Enter your courier address to complete your purchase.</p>
    </div>
    <div class="checkout-layout">
        <section class="panel">
            <form action="order-success.php" method="POST" class="form-grid">
                <input type="text" name="firstName" placeholder="First Name" required>
                <input type="text" name="lastName" placeholder="Last Name" required>
                <input type="email" name="email" placeholder="Email Address" required>
                <input type="tel" name="phone" placeholder="Phone Number" required>
                <input type="text" name="address" placeholder="Street Address" required class="span-2">
                <input type="text" name="city" placeholder="City" required>
                <select name="province" required>
                    <option value="">Select Province</option>
                    <option>Gauteng</option><option>Western Cape</option><option>KwaZulu-Natal</option><option>Eastern Cape</option><option>Limpopo</option>
                </select>
                <textarea name="notes" placeholder="Delivery notes (optional)" class="span-2"></textarea>
                <button type="submit" class="btn span-2">Place Order</button>
            </form>
        </section>
        <aside class="panel summary-panel">
            <h2>Order Summary</h2>
            <?php foreach ($cart as $id => $qty): if (!isset($products[$id])) continue; $p=$products[$id]; ?>
                <div class="summary-row"><span><?php echo htmlspecialchars($p['name']); ?> x<?php echo $qty; ?></span><strong>R<?php echo number_format($p['price']*$qty,0); ?></strong></div>
            <?php endforeach; ?>
            <div class="summary-row total"><span>Total</span><strong>R<?php echo number_format($total,0); ?></strong></div>
        </aside>
    </div>
</main>
<footer class="footer">Pastimes © 2026 | Buy. Sell. Wear Again.</footer>
</body>
</html>

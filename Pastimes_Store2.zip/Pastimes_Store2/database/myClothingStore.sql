CREATE DATABASE IF NOT EXISTS ClothingStore;
USE ClothingStore;

DROP TABLE IF EXISTS tblCart;
DROP TABLE IF EXISTS tblOrder;
DROP TABLE IF EXISTS tblProduct;
DROP TABLE IF EXISTS tblAdmin;
DROP TABLE IF EXISTS tblUser;

CREATE TABLE tblUser (
    userID INT AUTO_INCREMENT PRIMARY KEY,
    fullName VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(50) DEFAULT 'Buyer',
    status VARCHAR(50) DEFAULT 'Pending'
);

CREATE TABLE tblAdmin (
    adminID INT AUTO_INCREMENT PRIMARY KEY,
    adminEmail VARCHAR(100) NOT NULL,
    password VARCHAR(255) NOT NULL
);

CREATE TABLE tblProduct (
    productID INT AUTO_INCREMENT PRIMARY KEY,
    productName VARCHAR(100) NOT NULL,
    brand VARCHAR(100),
    price DECIMAL(10,2) NOT NULL,
    description TEXT,
    image VARCHAR(255),
    quantity INT DEFAULT 1
);

CREATE TABLE tblCart (
    cartID INT AUTO_INCREMENT PRIMARY KEY,
    userID INT,
    productID INT,
    quantity INT DEFAULT 1,
    FOREIGN KEY (userID) REFERENCES tblUser(userID),
    FOREIGN KEY (productID) REFERENCES tblProduct(productID)
);

CREATE TABLE tblOrder (
    orderID INT AUTO_INCREMENT PRIMARY KEY,
    userID INT,
    totalAmount DECIMAL(10,2),
    deliveryAddress TEXT,
    orderDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (userID) REFERENCES tblUser(userID)
);

INSERT INTO tblUser (fullName,email,username,password,role,status) VALUES
('John Doe','john@example.com','johnd','29ef52e7563626a96cea7f4b4085c124','Buyer','Approved'),
('Mary Smith','mary@example.com','marys','29ef52e7563626a96cea7f4b4085c124','Buyer','Pending'),
('Lebo Mokoena','lebo@example.com','lebom','29ef52e7563626a96cea7f4b4085c124','Seller','Approved'),
('Aisha Khan','aisha@example.com','aishak','29ef52e7563626a96cea7f4b4085c124','Seller','Pending'),
('Peter Jones','peter@example.com','peterj','29ef52e7563626a96cea7f4b4085c124','Buyer','Approved');

INSERT INTO tblAdmin (adminEmail,password) VALUES
('admin@pastimes.co.za','29ef52e7563626a96cea7f4b4085c124');

INSERT INTO tblProduct (productName,brand,price,description,image,quantity) VALUES
('Nike Air Max','Nike',200.00,'Pre-owned sneakers in good condition.','shoe.jpg',4),
('Denim Jacket','Levi''s',60.00,'Classic denim jacket.','jecket.jpg',2),
('Tropical Heels','Aldo',170.00,'Stylish heels.','heels.jpeg',3),
('Coach Bag','Coach',250.00,'Elegant handbag.','Coach.jpeg',2),
('Tropical Top','Zara',100.00,'Light fashion top.','Top.jpeg',5);

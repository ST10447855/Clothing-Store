<?php
session_start();
$orderRef = 'PT-' . date('Ymd') . '-' . rand(1000,9999);
$_SESSION['cart'] = [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Order Successful - Pastimes</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include 'partial_header.php'; ?>
<main class="page-container success-wrap">
    <div class="panel success-card">
        <div class="success-icon">✓</div>
        <h1>Order Successful</h1>
        <p>Your order has been placed successfully. Thank you for shopping with Pastimes.</p>
        <p><strong>Reference Number:</strong> <?php echo $orderRef; ?></p>
        <a href="products.php" class="btn">Continue Shopping</a>
    </div>
</main>
<footer class="footer">Pastimes © 2026 | Buy. Sell. Wear Again.</footer>
</body>
</html>

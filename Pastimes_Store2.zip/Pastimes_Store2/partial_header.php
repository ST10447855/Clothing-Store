<?php if (session_status() === PHP_SESSION_NONE) { session_start(); } ?>
<header class="navbar">
    <a href="index.php" class="logo">
        <img src="images/logo.jpeg" alt="Pastimes logo">
        <span>Pastimes</span>
    </a>
    <button class="menu-toggle" onclick="toggleMenu()">☰</button>
    <nav id="nav-links">
        <a href="index.php">Home</a>
        <a href="products.php">Shop</a>
        <a href="sell.php">Sell</a>
        <a href="messages.php">Messages</a>
        <a href="cart.php" class="cart-link">Cart <span class="cart-pill"><?php echo isset($_SESSION['cart']) ? array_sum($_SESSION['cart']) : 0; ?></span></a>
        <a href="profile.php">Profile</a>
        <a href="adminLogin.php">Admin</a>
        <a href="login.php">Login</a>
        <a href="register.php" class="btn-signup">Sign Up</a>
    </nav>
</header>
<script>
function toggleMenu(){ document.getElementById('nav-links').classList.toggle('active'); }
</script>

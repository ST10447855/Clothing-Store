<?php
session_start();
include 'products_data.php';
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if (!isset($_SESSION['cart'])) { $_SESSION['cart'] = []; }
if (isset($products[$id])) {
    $_SESSION['cart'][$id] = ($_SESSION['cart'][$id] ?? 0) + 1;
}
header('Location: cart.php');
exit;
?>
